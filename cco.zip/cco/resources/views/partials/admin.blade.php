
<div class="panel-body">
	<a href="{{ url('/auth/register') }}">Add New Agent</a>
</div>
<div class="panel-body">
	<a href="{{ action("ClientController@create") }}">Add New Client</a>
</div>
<div class="panel-body">
	<a href="{{ action("TempController@index") }}">Review New Clients</a>
</div>
<div class="panel-body">
	<a href="{{ action("ClientController@index") }}">Review All Clients</a>
</div>