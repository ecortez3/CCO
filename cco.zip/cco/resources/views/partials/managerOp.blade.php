<div class="panel-body">
	<a href="{{ action("MealController@meal") }}">Meal Counter</a>
</div>
<div class="panel-body">
	<a href="{{ action("ReportController@viewIndex") }}">Reporter</a>
</div>